;/*FB_PKG_DELIM*/

__d("IGDEnableOffMsysComposerQE.relayprovider",["qex"],(function(a,b,c,d,e,f,g){"use strict";a={get:function(){return c("qex")._("842")===!0}};g["default"]=a}),98);
__d("PolarisAccountStatusDisableRootQuery_instagramRelayOperation",[],(function(a,b,c,d,e,f){e.exports="9729749753805854"}),null);