;/*FB_PKG_DELIM*/

__d("SupportPortalsCaseListQuery_facebookRelayOperation",[],(function(a,b,c,d,e,f){e.exports="9570551213054452"}),null);
__d("VultureJSSampleRatesLoader",["VultureJSSampleRates","asyncToGeneratorRuntime"],(function(a,b,c,d,e,f,g){"use strict";function a(){return h.apply(this,arguments)}function h(){h=b("asyncToGeneratorRuntime").asyncToGenerator(function*(){return c("VultureJSSampleRates").sample_rates});return h.apply(this,arguments)}g.loadSampleRates=a}),98);