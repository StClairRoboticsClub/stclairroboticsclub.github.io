;/*FB_PKG_DELIM*/

/**
 * License: https://www.facebook.com/legal/license/cr2jmG-CdKo/
 */
__d("react-0.0.0",["React"],(function(a,b,c,d,e,f){"use strict";var g=b("React");c={};var h={exports:c};function i(){h.exports=g}var j=!1;function k(){j||(j=!0,i());return h.exports}d={};var l={exports:d};function m(){l.exports=g}var n=!1;function o(){n||(n=!0,m());return l.exports}function a(a){switch(a){case void 0:return k();case"/jsx-runtime":return o()}}e.exports=a}),null);
__d("react",["react-0.0.0"],(function(a,b,c,d,e,f){e.exports=b("react-0.0.0")()}),null);