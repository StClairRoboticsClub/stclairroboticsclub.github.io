;/*FB_PKG_DELIM*/

__d("YpIgFamilyCenterCoreClientEventFalcoEvent",["FalcoLoggerInternal","getFalcoLogPolicy_DO_NOT_USE"],(function(a,b,c,d,e,f,g){"use strict";a=c("getFalcoLogPolicy_DO_NOT_USE")("1772");b=d("FalcoLoggerInternal").create("yp_ig_family_center_core_client_event",a);e=b;g["default"]=e}),98);
__d("YpIgFamilyCenterSetupClientEventFalcoEvent",["FalcoLoggerInternal","getFalcoLogPolicy_DO_NOT_USE"],(function(a,b,c,d,e,f,g){"use strict";a=c("getFalcoLogPolicy_DO_NOT_USE")("1771");b=d("FalcoLoggerInternal").create("yp_ig_family_center_setup_client_event",a);e=b;g["default"]=e}),98);